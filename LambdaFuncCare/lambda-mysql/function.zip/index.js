const mysql = require('mysql2/promise');

exports.handler = async (event) => {
  const body = JSON.parse(event.body);

  const connection = await mysql.createConnection({
    host: 'atghealthcare.cjmme44o6mb1.ap-south-1.rds.amazonaws.com',
    user: 'your_user',
    password: 'your_password',
    database: 'your_database',
  });

  try {
    const [result] = await connection.execute(
      `INSERT INTO care_intake (client_username, care_navigator_username, full_name) VALUES (?, ?, ?)`,
      [body.client_username, body.care_navigator_username, body.full_name]
    );

    await connection.end();

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Form submitted' }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message }),
    };
  }
};